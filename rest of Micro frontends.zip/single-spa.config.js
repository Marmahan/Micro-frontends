// root-application/single-spa.config.js

import {registerApplication, start} from 'single-spa';

registerApplication('navBar', () => import ('./src/navBar/navBar.app.js').then( module => module.navBar), () => true);
registerApplication('home', () => import('./src/home/home.app.js'), () => location.pathname === "" || location.pathname === "/" || location.pathname.startsWith('/home'));
registerApplication('contactus', () => import('./src/contactus/contactus.app.js'), () =>  location.pathname.startsWith('/contactus'));
registerApplication('about', () => import('./src/about/about.app.js'), () =>  location.pathname.startsWith('/about'));
registerApplication('register', () => import('./src/register/register.app.js'), () =>  location.pathname.startsWith('/register'));
registerApplication('signin', () => import('./src/signin/signin.app.js'), () =>  location.pathname.startsWith('/signin'));
registerApplication('signout', () => import('./src/signout/signout.app.js'), () =>  location.pathname.startsWith('/signout'));
registerApplication('newpost', () => import('./src/newpost/newpost.app.js'), () =>  location.pathname.startsWith('/newpost'));

start();