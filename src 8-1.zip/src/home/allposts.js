import React from "react";
import axios from 'axios';  //to make the post request
import Post from './post';

class Allposts extends React.Component{
  
  state = {
      posts: [],
      users : [],
      postid:'',
      postbody:''
  } 
  componentDidMount(){
    axios.get('http://localhost:1115/posts')
    .then(res =>{
        this.setState({
            posts: res.data
        })
    })
  }  

setpost =(e)=>{
    console.log(e)
    this.setState({
        postid : e
    })
    axios.get('http://localhost:1115/post/'+e)
    .then(res =>{
        console.log(res)
        this.setState({
            postbody: res.data
        })
    })

}

showpost =(e)=>{

}

render(){
    const {posts} = this.state;
    const plist = posts.length ? (
        posts.map(post =>{
            return (
                <div className="card" key={post._id}>
                    <div className="card blue-grey darken-1">
                        <div className="card-content white-text">
                            <span className="card-title"><a href={'#'} pid={post._id} onClick={() => {this.setpost(post._id)}}>{post.title}</a></span>
                            <span style={{fontSize:'11px', marginLeft:'10px'}}>{post.date.replace('T',' ').substring(0, 24-5)}</span>
                            <span className="right">{post.writer}</span>
                            <p>{post.body}</p>
                        </div>
                    </div>

                </div>
            )
        })
    ):(
        <div className="center">
            No posts
        </div>
    )
    return(
            this.state.postid ? (
                <div>
                    {this.state.postbody.data}
                </div>
            ) : (
                <div>{plist}</div>
            )
    )
  }
}

export default Allposts;